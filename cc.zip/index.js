mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 自由面板1 = new 自由面板("自由面板1","49px");
var 标签1 = new 标签("标签1",null);
var 自由面板2 = new 自由面板("自由面板2","101px");
var 标签2 = new 标签("标签2",null);
var 标签3 = new 标签("标签3",null);
var 图片框1 = new 图片框("图片框1",null);
var 图片验证码1 = new 图片验证码("图片验证码1",图片验证码1_验证完毕);
var CYS标签输入框1 = new CYS标签输入框("CYS标签输入框1",null,null,null);
var 按钮1 = new 按钮("按钮1",按钮1_被单击,null,null);
var 列表框1 = new 列表框("列表框1",false,列表框1_表项被单击,null);
var 按钮组1 = new 按钮组("按钮组1",按钮组1_被单击);
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
if(mui.os.plus){
    mui.plusReady(function() {
        主窗口_创建完毕();
        
    });
}else{
    window.onload=function(){ 
        主窗口_创建完毕();
        
    }
}
window.onresize=function(){
	主窗口_窗口尺寸改变();
};

function 主窗口_创建完毕(){
	自由面板1.置背景颜色("#3F51B4");
	自由面板1.置边框阴影("5px","1px","#C9C9C9");
	调整组件尺寸1();
	列表框1.添加项目("为什么会出现这个？","","mui-btn mui-btn-primary","+");
	列表框1.添加项目("我应该做些什么？","","mui-btn mui-btn-primary","+");
	列表框1.添加项目("我的ip会被记录吗？？","","mui-btn mui-btn-primary","+");
	按钮组1.置样式(0,"mui-btn mui-btn-primary");
	按钮组1.置样式(1,"mui-btn mui-btn-danger");
	按钮组1.置标题(0,"联系站长");
	按钮组1.置标题(1,"FAQ");
	CYS标签输入框1.置标题("输入验证码：");
	图片验证码1.置对齐方式(2);
}

function 主窗口_窗口尺寸改变(){
	调整组件尺寸1();
}

function 调整组件尺寸1(){




	窗口操作.置组件高度("自由面板2","" + (106/480 * 窗口操作.取窗口高度()) + "px");
	窗口操作.置组件左边("图片框1","" + (114/320 * 窗口操作.取窗口宽度()) + "px");
	窗口操作.置组件顶边("图片框1","" + (0/480 * 窗口操作.取窗口高度()) + "px");
	窗口操作.置组件宽度("图片框1","" + (104/320 * 窗口操作.取窗口宽度()) + "px");
	窗口操作.置组件高度("图片框1","" + (98/480 * 窗口操作.取窗口高度()) + "px");
}

function 按钮1_被单击(){
	图片验证码1.开始验证(CYS标签输入框1.取内容());
}

function 图片验证码1_验证完毕(验证结果){
	switch(验证结果){
		case true :
		窗口操作.打开指定网址("https://www.kenobi.cn",1);
		break;
		case false :
		仔仔弹出对话框1.错误("验证码错误,您或许是机器人!");
		break;
	}


}

function 列表框1_表项被单击(项目索引,项目标题,项目标记){
	switch(项目索引){
		case 0 :
		仔仔弹出对话框1.提示("管理员开启恶意流量拦截！",5000);
		break;
		case 1 :
		仔仔弹出对话框1.提示("输入验证码即可！",5000);
		break;
		case 2 :
		仔仔弹出对话框1.提示("会记录恶意IP！",5000);
		break;
	}
}

function 按钮组1_被单击(按钮索引){
	switch(按钮索引){
		case 0 :
		窗口操作.打开指定网址("http://www.kenobi.cn/contact",1);
		break;
		case 1 :
		仔仔弹出对话框1.错误("没有FAQ啧啧啧！");
		break;
	}
}