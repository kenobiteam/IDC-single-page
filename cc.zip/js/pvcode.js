    function 图片验证码(name,event1){   
        //name表示组件在被创建时的名称，event表示组件拥有的事件
        //如果组件有多个事件，可以在后面继续填写这些事件名称
        //例如：function 图片验证码(name,event1,event2,event3){
        
        //组件内部属性，仅供组件内部使用：
        this.名称 = name;
		var verifyCode = new GVerify(this.名称);
        //组件命令
		this.开始验证 = function (被验证内容){
		    document.getElementById(this.名称).style.float="center";
		    document.getElementById(this.名称).style.textAlign="center";
			document.getElementById(this.名称).style.lineHeight="60px";
			//var verifyCode = new GVerify(this.名称);
			   //pvcode();
			   //var pvcode = function(){
			   var result;
			   var res = verifyCode.validate(被验证内容);
			      if(res){
				       //alert("验证正确");
					   result = true;
					   //return result;
			      }else{
				       //alert("验证码错误");
					   result = false;
					   //return result;
			      }
				  event1(result);
		       //}
			//var 验证结果;
			   
		}
		//event1(验证结果);
		
		this.置宽度 = function (宽度){
		    document.getElementById(this.名称).style.width=宽度;
		}
		
		this.置高度 = function (高度){
		    document.getElementById(this.名称).style.height=高度;
		}
		
		this.置对齐方式 = function (对齐方式){
		    if (对齐方式==1){
			   document.getElementById(this.名称).style.width="200px";
			}else if (对齐方式==2){
			   document.getElementById(this.名称).style.width="100%";
			}else if (对齐方式==3){
			   var a = document.documentElement.clientWidth-200;
			   var b = a + "px";
			   document.getElementById(this.名称).style.width=b;
			}
		}
		
        //组件命令：
        this.置可视 = function (是否可视){
            if(是否可视==true){
                var div = document.getElementById(this.名称).parentNode;
                div.style.display="block";//显示	                
            }else{
                var div = document.getElementById(this.名称).parentNode;
                div.style.display="none"; //不占位隐藏               
            }
        } 
        
        //组件命令：
        this.置可视2 = function (是否可视){
            if(是否可视==true){
                var div = document.getElementById(this.名称).parentNode;
                div.style.visibility="visible";//显示	                
            }else{
                var div = document.getElementById(this.名称).parentNode;
                div.style.visibility="hidden"; //占位隐藏               
            }
        } 
        
        //组件事件
        //if(event1!=null){
 		//document.getElementById(this.名称).addEventListener("tap", function () {
        //        event1();//触发组件的相关事件，这里演示的是被单击事件
        //    });       	
        //}
    }