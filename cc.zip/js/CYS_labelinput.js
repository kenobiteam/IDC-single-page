    function CYS标签输入框(name,event,event2,event3){   
       /*作者：CYS。  QQ：649812788
		  有BUG请反馈,谢谢！
		*/
        this.名称 = name;
        
		//去除编辑框边框
		document.getElementById(name).getElementsByTagName("input")[0].style.border = "none";
		
		this.置标题对齐 = function(type){
			//0：左对齐   1：居中  2：右对齐
			var olabel = document.getElementById(this.名称).getElementsByTagName('label')[0];
			switch(type){
				case 0:
					olabel.style.textAlign = "left";
					break;
				case 1:
					olabel.style.textAlign = "center";
					break;
				case 2:
					olabel.style.textAlign = "right";
					break;
			}
		};
		
		this.删除分割线 = function(){
			var head = document.getElementsByTagName("head")[0];
			var style = head.getElementsByTagName("style");
			if(style.length!=0){
				var oldstyle = style[0].innerHTML;
				var tmp = "#"+name+":after{";
				var i = oldstyle.indexOf(tmp);
				if(i!=-1){
					//删除原来的样式
					oldstyle = 子文本替换(oldstyle,"\n","");
					var content = 取指定文本(oldstyle,tmp,"\\}");
					style[0].innerHTML = 子文本替换(oldstyle,tmp + content + "}","");
				}
			}
		};
		
		this.置分割线样式 = function(lineColor,lineWidth){
			var head = document.getElementsByTagName("head")[0];
			var style = head.getElementsByTagName("style");
			
			if(style.length==0){
				var ostyle = document.createElement("style");
				ostyle.type = "text/css";
				ostyle.innerHTML = "\n#"+name+":after{\ncontent:'';\ndisplay:block;\nwidth:"+lineWidth+";\nborder-bottom:1px solid "+lineColor+";\ntop:39px;\nposition:absolute;\nright:0;\n}\n";
				head.appendChild(ostyle);
			}else{
				var oldstyle = style[0].innerHTML;
				var tmp = "#"+name+":after{";
				var i = oldstyle.indexOf(tmp);
				if(i!=-1){
					//删除原来的样式
					oldstyle = 子文本替换(oldstyle,"\n","");
					var content = 取指定文本(oldstyle,tmp,"\\}");
					style[0].innerHTML = 子文本替换(oldstyle,tmp + content + "}","");
				}
				style[0].innerHTML += "\n#"+name+":after{\ncontent:'';\ndisplay:block;\nwidth:"+lineWidth+";\nborder-bottom:1px solid "+lineColor+";\ntop:39px;\nposition:absolute;\nright:0;\n}\n";
			}
		};
		
        //组件命令：
        this.置标题 = function (newTitle){
            //document.getElementById(this.名称).innerHTML=newTitle;
			var olabel = document.getElementById(this.名称).getElementsByTagName('label')[0];
			olabel.innerHTML = newTitle;
        } 
        
        //组件命令：
        this.取标题 = function (){
           return document.getElementById(this.名称).getElementsByTagName('label')[0].innerHTML;
        }  
        
        //组件命令：
        this.置可视 = function (value){
            if(value==true){
                var div = document.getElementById(this.名称).parentNode;
                div.style.display="block";//显示	                
            }else{
                var div = document.getElementById(this.名称).parentNode;
                div.style.display="none"; //不占位隐藏               
            }
        } 
        
        //组件命令：
        this.置可视2 = function (value){
            if(value==true){
                var div = document.getElementById(this.名称).parentNode;
                div.style.visibility="visible";//显示	                
            }else{
                var div = document.getElementById(this.名称).parentNode;
                div.style.visibility="hidden"; //占位隐藏               
            }
        } 
        
		/*----------------------------【命令】---------------------------*/
		this.置提示内容 = function(newTips){
			var oinput = document.getElementById(this.名称).getElementsByTagName('input')[0];
			oinput.setAttribute('placeholder',newTips);
		}
		
		this.取提示内容 = function(){
			var oinput = document.getElementById(this.名称).getElementsByTagName('input')[0];
			return oinput.getAttribute('placeholder');
		}
		
		this.置内容 = function(content){
			var oinput = document.getElementById(this.名称).getElementsByTagName('input')[0];
			oinput.value = content;
		}
		
		this.取内容 = function(){
			var oinput = document.getElementById(this.名称).getElementsByTagName('input')[0];
			return oinput.value;
		}
		
		this.置样式 = function(type){//0：普通 1：密码
			var odiv = document.getElementById(this.名称);
			var txt = odiv.getElementsByTagName('label')[0].innerHTML;
			var oinput = odiv.getElementsByTagName('input')[0];
			var tips = oinput.getAttribute('placeholder');
			var content = oinput.value;
			var newClassName,newType;
			if(type==0){
				newType = "text";
				newClassName = "mui-input-clear";
			}else{
				newType = "password";
				newClassName = "mui-input-password";
			}
			if(tips==null){tips=""}
			odiv.innerHTML = "<label>" + txt + "</label>"
							+ "<input type='"+newType+"' class='"+newClassName+"' placeholder='"+tips+"' value='"+content+"'>";
			mui('.mui-input-row input').input();
			odiv.getElementsByTagName("input")[0].style.border = "none";	
		}
		
		
        //组件事件
        if(event!=null){
 		document.getElementById(this.名称).addEventListener("tap", function () {
                event();//触发组件的相关事件，这里演示的是被单击事件
            });       	
        }
		
		if(event2!=null){
			document.getElementById(this.名称).addEventListener("keydown", function (e) {
				var keynum = window.event ? e.keyCode : e.which;
				event2(keynum);//按下某键事件
			});
		}
		
		if(event3!=null){
			//内容被改变
			document.getElementById(name).getElementsByTagName("input")[0].oninput = function(){
				event3(this.value);
			}
		}
		
		/*------------------------------------*/
		function 取指定文本(待取文本,左边文本,右边文本){
			var pattern = new RegExp(左边文本 + "(.*?)" + 右边文本,"g");
			var result = new Array(0);
			while (pattern.exec(待取文本) != null){
				result.push(RegExp.$1);
			}
			return result;
		}
		
		function 子文本替换(str, a, b) {
            if(str==null || a==null || b==null){
                return "";
            }         
            var regExp = new RegExp(a, "g");
            return str.replace(regExp, b);
		}
    }